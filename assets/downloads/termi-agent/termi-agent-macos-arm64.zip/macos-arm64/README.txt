termi-agent (macOS Apple Silicon)

1) Unzip this package
2) Open terminal in this folder
3) Start: ./start-agent.sh
4) Stop:  ./stop-agent.sh

The agent listens on 8787 by default.
Use the printed Tailscale URL in the mobile app pairing page.
